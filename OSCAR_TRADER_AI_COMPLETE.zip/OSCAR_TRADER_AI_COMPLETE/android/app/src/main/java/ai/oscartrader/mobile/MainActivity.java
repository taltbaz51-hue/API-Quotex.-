package ai.oscartrader.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.view.KeyEvent;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        String base = BuildConfig.SERVER_URL.replaceAll("/+$", "");
        if (base.contains("YOUR-RENDER-SERVICE")) {
            Toast.makeText(this, "Set SERVER_URL in GitHub Actions before building APK", Toast.LENGTH_LONG).show();
        }
        web.loadUrl(base + BuildConfig.START_PATH);
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) {
            web.goBack(); return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
