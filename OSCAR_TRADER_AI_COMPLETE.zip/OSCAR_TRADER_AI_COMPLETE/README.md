# OSCAR TRADER AI — Server + Android user/admin apps

This is a starter deployment project with:
- FastAPI server and responsive web dashboards
- Separate Android user and admin APK variants (same Android source, separate app IDs)
- GitHub Actions workflow that builds both APKs and uploads them as workflow artifacts
- Render blueprint for a persistent demo server

## Important scope and safety
This build is DEMO/configuration only. It does not log in to Quotex, scrape private endpoints, store broker passwords, or place trades. Live trading and automated execution are intentionally not implemented. Only add a broker adapter if you have a documented, authorized integration and have verified the platform terms and applicable law.

The admin page is a starter interface, not a finished multi-user identity/role system. Do not expose it publicly without adding proper authentication, authorization, rate limiting, HTTPS, audit logging, and security review. Keep `ADMIN_TOKEN` private. Do not commit `.env`.

## 1) Deploy server to Render
1. Push this project to a GitHub repository.
2. In Render, choose **New +** -> **Blueprint** and select the repository containing `render.yaml`.
3. Review the service and create it. The blueprint creates a Docker web service and a persistent disk. This uses a paid Render plan/disk; free instances may sleep and do not provide durable local SQLite storage.
4. After deployment, copy the service URL, e.g. `https://your-service.onrender.com`.
5. In Render Environment, verify `ADMIN_TOKEN` is generated and private.
6. Open `https://your-service.onrender.com/health`. Expect JSON with `"ok": true`.

## 2) Build two Android APKs on GitHub
1. Open repository **Settings** -> **Secrets and variables** -> **Actions** -> **Variables**.
2. Add repository variable `SERVER_URL` with the exact HTTPS Render URL (no trailing slash).
3. Open **Actions** -> **Build Android APKs** -> **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the successful run and download artifact `oscar-android-apks`. It contains:
   - `app-user-release.apk` (filename may include Gradle variant naming)
   - `app-admin-release.apk`
6. Download the ZIP artifact to Android, extract it, and install each APK. Android may ask permission to install from that browser/file manager.

## 3) Local server test
From `backend/`:
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# Set ADMIN_TOKEN to a long random value in your shell before running
uvicorn app:app --host 0.0.0.0 --port 8000
```
Open `http://127.0.0.1:8000/` for user dashboard, `/admin` for admin dashboard, `/health` for health.

## 4) Demo settings API
`PUT /api/settings` requires header `X-Admin-Token` and accepts demo-only settings. `auto_trade=true` and live mode are rejected by design.

## 5) What remains before a real product
- Real authentication, password reset, user roles and admin-only audit endpoints
- Proper database such as PostgreSQL for multi-user production
- Automated tests, monitoring, backups, rate limits and security review
- A broker integration only if officially documented/authorized; otherwise use manual signal display and demo simulation
- Separate signing/release process for production Android apps (protect keystore and passwords as GitHub secrets)
