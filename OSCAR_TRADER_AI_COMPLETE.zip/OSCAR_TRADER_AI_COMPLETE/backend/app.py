import os, sqlite3, secrets
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).parent
DATA_DIR = Path(os.getenv("DATA_DIR", str(BASE / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB = DATA_DIR / "oscar.db"
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")
app = FastAPI(title="OSCAR TRADER AI API", version="1.0.0")

def connect():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def initialize():
    with connect() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS settings(
          key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS events(
          id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL,
          level TEXT NOT NULL, message TEXT NOT NULL)""")
        defaults = {"mode":"demo", "strategy":"order_block", "timeframe":"1m",
                    "auto_trade":"false", "service_name":"OSCAR TRADER AI"}
        for k,v in defaults.items():
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",(k,v))

@app.on_event("startup")
def startup():
    initialize()

def require_admin(token):
    if not ADMIN_TOKEN:
        raise HTTPException(503, "ADMIN_TOKEN is not configured on the server")
    if not token or not secrets.compare_digest(token, ADMIN_TOKEN):
        raise HTTPException(401, "Invalid administrator token")

class DemoSettings(BaseModel):
    strategy: str = Field(min_length=2, max_length=80)
    timeframe: str = Field(pattern="^(5s|15s|30s|1m|2m|5m|15m)$")
    mode: str = Field(default="demo", pattern="^demo$")
    auto_trade: bool = False

def read_settings():
    with connect() as c:
        rows = c.execute("SELECT key,value FROM settings").fetchall()
    d = {r["key"]:r["value"] for r in rows}
    return {"mode":d.get("mode","demo"), "strategy":d.get("strategy","order_block"),
            "timeframe":d.get("timeframe","1m"), "auto_trade":d.get("auto_trade")=="true"}

@app.get("/health")
def health():
    return {"ok":True,"service":"OSCAR TRADER AI","mode":"demo",
            "timestamp":datetime.now(timezone.utc).isoformat()}

@app.get("/api/settings")
def settings():
    return read_settings()

@app.put("/api/settings")
def save_settings(payload: DemoSettings, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    if payload.auto_trade:
        raise HTTPException(409, "Automated execution is disabled in this build.")
    values = payload.model_dump()
    with connect() as c:
        for k,v in values.items():
            c.execute("""INSERT INTO settings(key,value) VALUES(?,?)
                         ON CONFLICT(key) DO UPDATE SET value=excluded.value""",
                      (k, str(v).lower() if isinstance(v,bool) else v))
        c.execute("INSERT INTO events(at,level,message) VALUES(?,?,?)",
                  (datetime.now(timezone.utc).isoformat(),"INFO","Demo settings saved"))
    return {"saved":True,"settings":read_settings()}

@app.get("/api/events")
def events():
    with connect() as c:
        rows = c.execute("SELECT id,at,level,message FROM events ORDER BY id DESC LIMIT 40").fetchall()
    return [dict(r) for r in rows]

@app.get("/", response_class=HTMLResponse)
def user_dashboard():
    return (BASE/"static"/"user.html").read_text(encoding="utf-8")

@app.get("/admin", response_class=HTMLResponse)
def admin_dashboard():
    return (BASE/"static"/"admin.html").read_text(encoding="utf-8")

app.mount("/static", StaticFiles(directory=BASE/"static"), name="static")
