from config import Config
from services.strategy_engine import validate_strategy
from services.quotex_official_adapter import QuotexOfficialAdapter
from services.demo_broker import DemoBroker

class BrokerGateway:
    """Single controlled boundary between strategy logic and a broker adapter."""
    def __init__(self):
        self.demo = DemoBroker()
        self.quotex = QuotexOfficialAdapter()

    def status(self):
        return {
            "mode": Config.BROKER_MODE,
            "demo_available": True,
            "live_available": self.quotex.is_configured(),
            "live_message": self.quotex.status_message(),
            "execution_path": "strategy -> risk checks -> broker gateway -> adapter"
        }

    def _checks(self, order):
        if not isinstance(order, dict):
            return False, "Order must be an object"
        if order.get("direction") not in {"call", "put"}:
            return False, "direction must be call or put"
        try:
            amount = float(order.get("amount", 0))
            expiry = int(order.get("expiry_seconds", 0))
        except (TypeError, ValueError):
            return False, "amount and expiry_seconds must be numeric"
        if amount <= 0 or amount > Config.MAX_TRADE_AMOUNT:
            return False, f"amount must be between 0 and {Config.MAX_TRADE_AMOUNT}"
        if expiry < 5 or expiry > 3600:
            return False, "expiry_seconds must be between 5 and 3600"
        ok, reason = validate_strategy(order.get("strategy", {}))
        if not ok:
            return False, reason
        return True, "Risk and strategy checks passed"

    def preview(self, order):
        ok, reason = self._checks(order)
        return {"ok": ok, "mode": Config.BROKER_MODE, "reason": reason,
                "live_execution": False, "order": order if ok else None}

    def place_demo(self, order):
        ok, reason = self._checks(order)
        if not ok:
            return {"ok": False, "error": reason}
        return self.demo.place_order(order)
