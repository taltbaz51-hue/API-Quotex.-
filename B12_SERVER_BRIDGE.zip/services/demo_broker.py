import uuid
from datetime import datetime, timezone

class DemoBroker:
    def place_order(self, order):
        return {
            "ok": True,
            "mode": "demo_simulation",
            "order_id": str(uuid.uuid4()),
            "asset": order.get("asset", "UNKNOWN"),
            "direction": order["direction"],
            "amount": float(order["amount"]),
            "expiry_seconds": int(order["expiry_seconds"]),
            "status": "simulated_not_sent_to_exchange",
            "created_at": datetime.now(timezone.utc).isoformat()
        }
