class QuotexOfficialAdapter:
    """Fail-closed placeholder for an authorized, documented Quotex API.

    Do not replace this with browser automation, private endpoints, or captured
    session cookies. Implement only when the platform supplies an approved API.
    """
    def is_configured(self):
        return False

    def status_message(self):
        return "Live trading disabled: no authorized documented Quotex API configured."

    def place_order(self, order):
        raise RuntimeError(self.status_message())
