ALLOWED_DIRECTIONS = {"call", "put"}

def validate_strategy(data):
    if not isinstance(data, dict):
        return False, "Strategy must be an object"
    if not data.get("id"):
        return False, "Strategy id is required"
    if data.get("entry") is not True:
        return False, "No confirmed entry condition"
    return True, "Strategy conditions accepted for preview"
