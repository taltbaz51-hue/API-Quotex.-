# B12 Server Bridge

A Flask backend with a broker-gateway layer between the strategy engine and any trading venue.

## Important
- This package is a real runnable server, but its included broker is **DEMO-only**.
- It does not log in to Quotex, automate its website, reuse private session cookies, or place live orders.
- `QuotexOfficialAdapter` is an integration contract placeholder. Live execution stays disabled until Quotex provides an authorized, documented API and the adapter is implemented against that documentation.
- Never put account passwords, SSIDs, cookies, or API secrets in source code or send them in chat.

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python run.py
```
Server: `http://127.0.0.1:5000`

## API
- `GET /health`
- `GET /api/broker/status`
- `POST /api/strategy/validate`
- `POST /api/orders/preview` - validates strategy and risk limits; does not place an order
- `POST /api/orders/demo` - records a simulated demo order only

Example demo order:
```json
{
  "asset": "EURUSD",
  "direction": "call",
  "amount": 1,
  "expiry_seconds": 60,
  "strategy": {"id": "manual_signal", "entry": true}
}
```

Set a strong `API_TOKEN` in `.env` and send it as `X-API-Token`.
