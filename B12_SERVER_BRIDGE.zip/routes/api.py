from flask import Blueprint, request, jsonify
from security import require_token
from services.strategy_engine import validate_strategy
from services.broker_gateway import BrokerGateway
from storage import add_order, count_orders_today

api = Blueprint("api", __name__)
gateway = BrokerGateway()

@api.before_request
def auth():
    return require_token()

@api.get("/broker/status")
def broker_status():
    return jsonify(gateway.status())

@api.post("/strategy/validate")
def strategy_validate():
    data = request.get_json(silent=True) or {}
    ok, reason = validate_strategy(data)
    return jsonify({"ok": ok, "reason": reason}), (200 if ok else 400)

@api.post("/orders/preview")
def order_preview():
    data = request.get_json(silent=True) or {}
    result = gateway.preview(data)
    return jsonify(result), (200 if result["ok"] else 400)

@api.post("/orders/demo")
def demo_order():
    data = request.get_json(silent=True) or {}
    result = gateway.place_demo(data)
    if result["ok"]:
        add_order(result)
    return jsonify(result), (201 if result["ok"] else 400)
