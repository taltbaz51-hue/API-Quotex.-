from flask import Blueprint, jsonify
health = Blueprint("health", __name__)

@health.get("/health")
def ping():
    return jsonify({"ok": True, "service": "B12 Server Bridge"})
