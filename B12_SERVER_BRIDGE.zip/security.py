from functools import wraps
from flask import request, jsonify
from config import Config

def require_token():
    # Empty token is rejected so the API is never accidentally public.
    if not Config.API_TOKEN or request.headers.get("X-API-Token", "") != Config.API_TOKEN:
        return jsonify({"ok": False, "error": "Unauthorized: configure API_TOKEN and send X-API-Token"}), 401
    return None
