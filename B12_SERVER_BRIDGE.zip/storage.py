import sqlite3
from pathlib import Path
from datetime import date

DB = Path("b12_orders.sqlite3")

def _connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def add_order(order):
    with _connect() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS orders
            (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT, asset TEXT,
             direction TEXT, amount REAL, status TEXT, created_at TEXT)''')
        con.execute('''INSERT INTO orders(order_id,asset,direction,amount,status,created_at)
            VALUES(?,?,?,?,?,?)''', (order.get("order_id"), order.get("asset"),
            order.get("direction"), order.get("amount"), order.get("status"),
            order.get("created_at")))

def count_orders_today():
    with _connect() as con:
        con.execute("CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, created_at TEXT)")
        row = con.execute("SELECT COUNT(*) AS n FROM orders WHERE substr(created_at,1,10)=?",
                          (date.today().isoformat(),)).fetchone()
        return row["n"]
