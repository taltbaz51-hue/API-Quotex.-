from flask import Flask
from routes.api import api
from routes.health import health

def create_app():
    app = Flask(__name__)
    app.register_blueprint(health)
    app.register_blueprint(api, url_prefix="/api")
    return app
