import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    HOST = os.getenv("HOST", "127.0.0.1")
    PORT = int(os.getenv("PORT", "5000"))
    API_TOKEN = os.getenv("API_TOKEN", "")
    BROKER_MODE = os.getenv("BROKER_MODE", "demo").lower()
    MAX_TRADE_AMOUNT = float(os.getenv("MAX_TRADE_AMOUNT", "5"))
    MAX_DAILY_ORDERS = int(os.getenv("MAX_DAILY_ORDERS", "20"))
