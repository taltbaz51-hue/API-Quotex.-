from datetime import datetime, timezone
from typing import Literal
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

app = FastAPI(title="Oscar Trader AI", version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

class Candle(BaseModel):
    open: float
    high: float
    low: float
    close: float
    volume: float = 0

class AnalyzeRequest(BaseModel):
    symbol: str = Field(default="EURUSD", min_length=3, max_length=20)
    timeframe: str = Field(default="1m", max_length=5)
    strategy: Literal["ema_rsi", "order_block", "combined"] = "combined"
    candles: list[Candle] = Field(default_factory=list, max_length=500)

def ema(values, period):
    if len(values) < period:
        return None
    alpha = 2 / (period + 1)
    result = sum(values[:period]) / period
    for value in values[period:]:
        result = alpha * value + (1 - alpha) * result
    return result

def rsi(values, period=14):
    if len(values) <= period:
        return None
    changes = [values[i] - values[i-1] for i in range(1, len(values))]
    gains = [max(x, 0) for x in changes]
    losses = [max(-x, 0) for x in changes]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for gain, loss in zip(gains[period:], losses[period:]):
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
    return 100.0 if avg_loss == 0 else 100 - 100 / (1 + avg_gain / avg_loss)

def order_block_hint(candles):
    if len(candles) < 4:
        return "بيانات غير كافية"
    last = candles[-1]
    previous = candles[-4:-1]
    if last.close > max(c.high for c in previous):
        return "اختراق صاعد؛ راقب آخر شمعة هابطة"
    if last.close < min(c.low for c in previous):
        return "اختراق هابط؛ راقب آخر شمعة صاعدة"
    return "لا يوجد كسر واضح"

@app.get("/", response_class=HTMLResponse)
def home():
    return open("static/index.html", encoding="utf-8").read()

@app.get("/api/health")
def health():
    return {"status": "ok", "app": "Oscar Trader AI",
            "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/config")
def config():
    return {"account_mode": "demo", "live_trading_enabled": False,
            "strategies": ["ema_rsi", "order_block", "combined"],
            "timeframes": ["5s", "15s", "30s", "1m", "5m", "15m"]}

@app.post("/api/analyze")
def analyze(data: AnalyzeRequest):
    closes = [c.close for c in data.candles]
    fast, slow, momentum = ema(closes, 9), ema(closes, 21), rsi(closes)
    signal, confidence = "انتظار", 0
    if fast is not None and slow is not None and momentum is not None:
        if fast > slow and 50 < momentum < 70:
            signal, confidence = "مراقبة صعود", 65
        elif fast < slow and 30 < momentum < 50:
            signal, confidence = "مراقبة هبوط", 65
    return {"symbol": data.symbol, "timeframe": data.timeframe,
            "strategy": data.strategy, "signal": signal, "confidence": confidence,
            "ema9": fast, "ema21": slow, "rsi14": momentum,
            "order_block": order_block_hint(data.candles), "mode": "demo",
            "disclaimer": "تحليل تعليمي فقط؛ ليس أمراً تداولياً ولا يضمن نتيجة."}

@app.get("/api/quotex/status")
def quotex_status():
    return {"connected": False, "mode": "demo", "integration": "not_configured",
            "message": "لا يوجد موصل رسمي موثق مهيأ. لا تدخل بيانات حسابك في هذه النسخة."}

@app.post("/api/quotex/connect")
def quotex_connect():
    raise HTTPException(status_code=501,
        detail="الاتصال المباشر غير مفعّل. يلزم موصل موثوق ومصرح به من مزود المنصة.")
